<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
?>

<?php

echo "<br><br>";

echo $details['pr_nom'];

echo "<br><br>";

echo "prix : ";
echo $details['pr_prix'];

echo "<br><br>";

echo "référence du produit : ";
echo $details['pr_reference'];

echo "<br><br>";

echo "Se situe dans le rayon ";
echo $details['ray_libelle'];

echo "<br><br>";

echo $details['pr_description'];

echo "<br><br>";

echo "Magasin ou l'article est disponible : ";

foreach ($lieuDispo as $lieu) {
  echo $lieu['ma_lieu'];
  echo ", ";
}


?>