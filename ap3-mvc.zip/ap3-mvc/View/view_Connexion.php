<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<a href="produits_perso.php"><h3>retour</h3></a>

<h1>Page de Connexion</h1>

<form action="ConnexionController.php" method="post">
    <div>
        <label for="name">Adresse Mail : </label>
        <input type="text" id="email" name="user_email">
    </div>
    <br>
    <div>
        <label for="name">Mot de Passe : </label>
        <input type="password" id="username" name="user_mdp">
        <br><br>
        <input type="submit" id="ValidConnexion" name="view_Connexion">
    </div>
</form>