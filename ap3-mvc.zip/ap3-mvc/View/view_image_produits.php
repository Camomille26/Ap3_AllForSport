<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<?php
include "../View/header.php"
?>

<h1>Produits</h1>

  <tbody>

    <?php
    foreach ($produits as $produit) {
      echo "<a href=/ap3-mvc-perso/Controller/detail_produit.php?id='" . $produit['pr_id'] . "'><img src='../img/" . $produit['imgproduit'] ."'>";
      echo $produit['pr_nom'];
    }
    ?>

  </tbody>
