-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ap3_boutique
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `entrepot`
--

DROP TABLE IF EXISTS `entrepot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrepot` (
  `en_id` int NOT NULL AUTO_INCREMENT,
  `en_lieu` varchar(45) NOT NULL,
  PRIMARY KEY (`en_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrepot`
--

LOCK TABLES `entrepot` WRITE;
/*!40000 ALTER TABLE `entrepot` DISABLE KEYS */;
INSERT INTO `entrepot` VALUES (1,'Havre'),(2,'Lyon'),(3,'Marseille');
/*!40000 ALTER TABLE `entrepot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `magasin`
--

DROP TABLE IF EXISTS `magasin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `magasin` (
  `ma_id` int NOT NULL AUTO_INCREMENT,
  `ma_lieu` varchar(45) NOT NULL,
  PRIMARY KEY (`ma_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `magasin`
--

LOCK TABLES `magasin` WRITE;
/*!40000 ALTER TABLE `magasin` DISABLE KEYS */;
INSERT INTO `magasin` VALUES (1,'Lille'),(2,'Arras'),(3,'Amiens'),(4,'Paris'),(5,'Reims'),(6,'Metz'),(7,'Rennes'),(8,'Tour'),(9,'Bordeaux'),(10,'Toulouse'),(11,'Nice'),(12,'Lyon');
/*!40000 ALTER TABLE `magasin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produit`
--

DROP TABLE IF EXISTS `produit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produit` (
  `pr_id` int NOT NULL AUTO_INCREMENT,
  `pr_nom` varchar(45) NOT NULL,
  `pr_prix` int NOT NULL,
  `pr_reference` varchar(45) NOT NULL,
  `pr_fournisseur` varchar(45) NOT NULL,
  `pr_rayon` varchar(45) NOT NULL,
  `pr_description` varchar(5000) NOT NULL,
  PRIMARY KEY (`pr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produit`
--

LOCK TABLES `produit` WRITE;
/*!40000 ALTER TABLE `produit` DISABLE KEYS */;
INSERT INTO `produit` VALUES (1,'Ballon de Football Classique',1000,'EURFOO1','EuropaSoccer','Football','Simple ballon de foot pour organiser vos meilleures parties de football en famille ou entre amis'),(2,'Lunette de plongée simple (bleu)',300,'NAGNAT1','NageDeFrance','Natation','Lunettes de plongées simples pour profiter de vos vacances en mer'),(3,'Vélo modèle Pro',150000,'MASCYC1','MasterOfTheRoad','Cyclisme','Vélo de compétition avec le meilleur rapport qualité-prix de France');
/*!40000 ALTER TABLE `produit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockentrepot`
--

DROP TABLE IF EXISTS `stockentrepot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stockentrepot` (
  `pr_fk` int NOT NULL,
  `en_fk` int NOT NULL,
  `en_stock` int NOT NULL,
  PRIMARY KEY (`pr_fk`,`en_fk`),
  KEY `en_en_fk_idx` (`en_fk`) /*!80000 INVISIBLE */,
  CONSTRAINT `en_fk` FOREIGN KEY (`en_fk`) REFERENCES `entrepot` (`en_id`),
  CONSTRAINT `pr_fk` FOREIGN KEY (`pr_fk`) REFERENCES `produit` (`pr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockentrepot`
--

LOCK TABLES `stockentrepot` WRITE;
/*!40000 ALTER TABLE `stockentrepot` DISABLE KEYS */;
INSERT INTO `stockentrepot` VALUES (1,1,100),(2,2,30),(2,3,50),(3,1,2);
/*!40000 ALTER TABLE `stockentrepot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockmagasin`
--

DROP TABLE IF EXISTS `stockmagasin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stockmagasin` (
  `ma_fk` int NOT NULL,
  `pr_fk` int NOT NULL,
  `ma_stock` int NOT NULL,
  PRIMARY KEY (`ma_fk`,`pr_fk`),
  KEY `pr_ma_fk_idx` (`pr_fk`),
  CONSTRAINT `ma_fk` FOREIGN KEY (`ma_fk`) REFERENCES `magasin` (`ma_id`),
  CONSTRAINT `pr_fk1` FOREIGN KEY (`pr_fk`) REFERENCES `produit` (`pr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockmagasin`
--

LOCK TABLES `stockmagasin` WRITE;
/*!40000 ALTER TABLE `stockmagasin` DISABLE KEYS */;
INSERT INTO `stockmagasin` VALUES (1,3,2),(4,1,25),(4,3,3);
/*!40000 ALTER TABLE `stockmagasin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-14 11:43:42
