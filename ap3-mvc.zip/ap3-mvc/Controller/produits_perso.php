<?php

require_once "../Model/bdd.php";

$bdd = new Bdd();

$produits = $bdd->getImageProduit();
require "../View/view_image_produits.php";

// var_dump($_GET);

?>