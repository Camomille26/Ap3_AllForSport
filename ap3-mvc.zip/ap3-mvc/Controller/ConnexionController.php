<?php

require_once "../Model/bdd.php";

require "../View/header.php";

require "../View/view_Connexion.php";

$bdd = new Bdd();

$user_email = $_POST["user_email"];
$user_mdp = $_POST["user_mdp"];

$verification = $bdd->getConnexionUser($user_email,$user_mdp);

if (!empty($verification)) {
    session_start([]);
    $_SESSION['login'] = $verification;
    header('Location: produits_perso.php');
} else {
    echo "Erreur d'identification";
}