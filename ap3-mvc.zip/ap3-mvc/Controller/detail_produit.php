<?php

require_once "../Model/bdd.php";

require "../View/header.php";

$refProduit = $_GET['id'];

$bdd = new Bdd();

$details = $bdd->getDetailProduit($refProduit);

$lieuDispo = $bdd->getDispo($refProduit);

require "../View/view_detail_produit.php";
