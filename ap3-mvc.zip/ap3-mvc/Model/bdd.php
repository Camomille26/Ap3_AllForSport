<?php

class Bdd
{
  private $bdd;

  public function __construct()
  {
    $dsn = 'mysql:dbname=ap3_boutique;host=127.0.0.1:3306';
    $dbUser = 'root';
    $dbPwd = '';

    try {
      $this->bdd = new PDO($dsn, $dbUser, $dbPwd);
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }

  public function getProduits(){
    $sql = "SELECT * FROM produit;";
    $query =  $this->bdd->prepare($sql);
    $query->execute();
    return $query->fetchAll();
  }

  public function getImageProduit(){
    $sql = "select pr_id, pr_nom, min(im_nom) as imgproduit from produit join image on pr_im_fk = pr_id group by pr_nom;";
    $query = $this->bdd->prepare($sql);
    $query->execute();
    return $query->fetchAll();
  }

  public function getDetailProduit($refProduit){
    $sql = "select pr_nom, pr_prix, pr_reference, ray_libelle, pr_description from produit join rayon on ray_id = ray_fk where pr_id = $refProduit;";
    $query = $this->bdd->prepare($sql);
    $query->execute();
    return $query->fetch();
  }

  public function getDispo($refProduit){
    $sql = "select ma_lieu from magasin join stockmagasin on ma_id = ma_fk where pr_fk = $refProduit;";
    $query = $this->bdd->prepare($sql);
    $query->execute();
    return $query->fetchAll();
  }

  public function getConnexionUser($user_email,$user_mdp){
    $sql = "select cli_id, cli_nom, cli_prenom from client where cli_email = '" . $user_email . "' and cli_mdp = '" . $user_mdp . "';";
    $query = $this->bdd->prepare($sql);
    $query->execute();
    return $query->fetch();
  }
}